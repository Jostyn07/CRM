-- ============================================================
-- CLIENTES — cada quien ve solo sus portales
-- Ruta: supabase/migrations/20261010000002_clientes_portales_visibilidad.sql
-- Requiere 20261010000001_clientes_portales.sql
--
--  · Administrador de organización: todos los portales.
--  · Administrador de sucursal y supervisor (alcance "Sucursal"):
--      con portales asignados → solo esos;
--      sin portales           → los portales de sus sucursales.
--  · Operador: ningún portal (solo ve los clientes de sus leads/chats).
--  La pantalla de Usuarios lee los portales directamente de la tabla
--  client_portals (quien administra usuarios los ve todos para asignarlos).
-- ============================================================

CREATE OR REPLACE FUNCTION public.clients_portals()
RETURNS TABLE (portal_key text, name text, branch_id uuid, branch_name text, clients_count bigint, users_count bigint)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = '' AS $$
DECLARE
  v_org uuid := public.my_org_id();
  v_scope text := public.permission_scope('clients.view');
  v_mine text[];
BEGIN
  IF v_scope IS NULL OR v_scope = 'own' THEN RETURN; END IF;
  IF v_scope = 'branch' THEN v_mine := public.my_client_portals(); END IF;
  RETURN QUERY
  SELECT cp.portal_key, cp.name, cp.branch_id, b.name,
         (SELECT count(*) FROM public.clients c WHERE c.organization_id = v_org AND c.portal_key = cp.portal_key),
         (SELECT count(*) FROM public.user_portals up WHERE up.organization_id = v_org AND up.portal_key = cp.portal_key)
    FROM public.client_portals cp
    LEFT JOIN public.branches b ON b.id = cp.branch_id
   WHERE cp.organization_id = v_org
     AND (v_scope = 'organization'
          OR (cardinality(v_mine) > 0 AND cp.portal_key = ANY (v_mine))
          OR (cardinality(v_mine) = 0 AND cp.branch_id = ANY (public.my_branch_ids())))
   ORDER BY cp.name;
END;
$$;
GRANT EXECUTE ON FUNCTION public.clients_portals() TO authenticated;

-- El total de Asesorías solo se guarda en sincronizaciones completas
-- (en las incrementales la API devuelve solo los que cambiaron).
UPDATE public.client_sources s
   SET total_remote = (SELECT count(*) FROM public.clients c WHERE c.organization_id = s.organization_id)
 WHERE total_remote IS NOT NULL
   AND total_remote < (SELECT count(*) FROM public.clients c WHERE c.organization_id = s.organization_id);
