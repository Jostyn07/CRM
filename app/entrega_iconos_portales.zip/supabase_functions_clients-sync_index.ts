// Ruta: supabase/functions/clients-sync/index.ts
// Trae los clientes de Asesorías (api-clientes-crm) y los guarda en la tabla
// clients. Solo lectura del lado de Asesorías.
//
// Dos formas de llamarla:
//   · Desde la app (botón "Sincronizar"): JWT de un usuario con clients.manage.
//       POST { full?: boolean }   → solo su organización
//   · Programada (pg_cron, 7:00 a. m. y 12:00 m. hora Colombia): header
//       x-webhook-secret = WEBHOOK_SECRET. POST { full: true } → todas las
//       organizaciones con sincronización automática. Responde de inmediato y
//       sigue trabajando en segundo plano.
//
// Incremental: pide solo los clientes con updated_at posterior a la última
// sincronización (updated_since). { full: true } vuelve a traer y ACTUALIZA
// todos (así se reflejan cambios en pólizas o dependientes aunque el cliente
// no haya cambiado). El portal de cada cliente se guarda en data.portal.
//
// Archivo autocontenido: se puede pegar tal cual en el editor del dashboard.
import { createClient } from "jsr:@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const admin = createClient(SUPABASE_URL, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
  auth: { persistSession: false, autoRefreshToken: false },
});
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });


// ---------------- CORS (según la petición)
// Acepta el origen si coincide con APP_URL (sin importar "/" final), con
// alguno de ALLOWED_ORIGINS (separados por coma) o si es un subdominio del
// dominio de APP_URL. Repite los encabezados que pida el navegador.
// Deja solo esquema + dominio (+ puerto): ignora rutas, "/" final y espacios
function normOrigin(u: string) {
  const s = u.trim();
  if (!s) return "";
  try {
    return new URL(s.includes("://") ? s : `https://${s}`).origin.toLowerCase();
  } catch {
    return s.replace(/\/+$/, "").toLowerCase();
  }
}
const CORS_ALLOWED = [Deno.env.get("APP_URL") ?? "", ...(Deno.env.get("ALLOWED_ORIGINS") ?? "").split(",")]
  .map(normOrigin)
  .filter(Boolean);

function corsFor(req: Request): Record<string, string> {
  const origin = normOrigin(req.headers.get("origin") ?? "");
  let allowed = CORS_ALLOWED.length === 0 || CORS_ALLOWED.includes(origin);
  if (!allowed && origin) {
    try {
      const host = new URL(origin).hostname;
      allowed = CORS_ALLOWED.some((a) => host.endsWith("." + new URL(a).hostname));
    } catch {
      allowed = false;
    }
  }
  if (!allowed) console.warn(`CORS: origen no permitido ${origin} (permitidos: ${CORS_ALLOWED.join(", ")})`);
  return {
    "Access-Control-Allow-Origin": allowed ? req.headers.get("origin") ?? "*" : "null",
    "Access-Control-Allow-Headers":
      req.headers.get("access-control-request-headers") ?? "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Max-Age": "86400",
    Vary: "Origin",
  };
}

// Envuelve el manejador: responde el preflight y agrega CORS a toda respuesta
function serveWithCors(handler: (req: Request) => Promise<Response> | Response) {
  Deno.serve(async (req) => {
    const headers = corsFor(req);
    if (req.method === "OPTIONS") return new Response("ok", { status: 200, headers });
    let res: Response;
    try {
      res = await handler(req);
    } catch (e) {
      console.error(e);
      res = new Response(JSON.stringify({ error: "Error interno" }), { status: 500, headers: { "Content-Type": "application/json" } });
    }
    const merged = new Headers(res.headers);
    for (const [k, v] of Object.entries(headers)) merged.set(k, v);
    return new Response(res.body, { status: res.status, headers: merged });
  });
}

// ---------------------------------------------------------------- Mapeo tolerante
// La API devuelve todas las columnas de "clientes"; aquí se buscan los campos
// clave por nombres posibles y el resto se guarda tal cual en data.
const SENSITIVE = /^(ssn|estado_migratorio|condiciones_medicas|tiene_social|numero_seguro_social|seguro_social|social_security|contrasena.*|password.*|clave_portal|email_portal|pin|cvv|tarjeta.*|numero_tarjeta|numero_cuenta|cuenta_bancaria|routing.*|numero_routing|metodo.*pago.*)$/i;
const PHONE_KEY = /(tel|cel|phone|whats|movil|móvil)/i;

type Row = Record<string, unknown>;
const str = (v: unknown) => (v === null || v === undefined ? "" : String(v).trim());
function pick(o: Row, keys: string[]): string {
  for (const k of keys) if (str(o[k])) return str(o[k]);
  return "";
}

function mapClient(c: Row) {
  const data: Row = {};
  const phones: string[] = [];
  for (const [k, v] of Object.entries(c)) {
    if (SENSITIVE.test(k) || k === "polizas" || k === "dependientes") continue;
    if (PHONE_KEY.test(k) && (typeof v === "string" || typeof v === "number") && str(v)) phones.push(str(v));
    data[k] = v;
  }
  // Portal de Asesorías (define la sucursal del cliente)
  const portal = pick(c, ["portal", "portal_nombre", "nombre_portal"]);
  if (portal) data.portal = portal;
  let first = pick(c, ["nombres", "nombre", "primer_nombre", "first_name"]);
  let last = pick(c, ["apellidos", "apellido", "primer_apellido", "last_name"]);
  const full = pick(c, ["nombre_completo", "full_name"]);
  if (!first && full) {
    const parts = full.split(/\s+/);
    first = parts.shift() ?? "";
    last = last || parts.join(" ");
  }
  const secrets: { policy_id: string; clave: string }[] = [];
  const policies = (Array.isArray(c.polizas) ? c.polizas : []).map((p: Row) => {
    const { clave_seguridad, contrasena_portal, email_portal, ...rest } = p ?? {};
    if (str(clave_seguridad)) secrets.push({ policy_id: str(p.id), clave: str(clave_seguridad) });
    return rest;
  });
  const dependents = (Array.isArray(c.dependientes) ? c.dependientes : []).map((d: Row) => {
    const out: Row = {};
    for (const [k, v] of Object.entries(d ?? {})) if (!SENSITIVE.test(k)) out[k] = v;
    return out;
  });
  const archived = c.archivado === true || c.archivado === "true";
  return {
    external_id: str(c.id),
    first_name: first,
    last_name: last,
    phones,
    email: pick(c, ["email", "correo", "correo_electronico", "email_cliente"]),
    birth_date: pick(c, ["fecha_nacimiento", "fecha_de_nacimiento", "nacimiento", "dob"]),
    operator_name: pick(c, ["operador_nombre", "operador", "asesor", "agente"]),
    archived,
    data,
    policies,
    dependents,
    secrets,
    created_at: str(c.created_at) || null,
    updated_at: str(c.updated_at) || null,
  };
}

// ---------------------------------------------------------------- Sincronizar una organización
async function syncOrg(t: { organization_id: string; base_url: string; api_token: string; updated_since: string | null; default_code: string }) {
  let page = 1, hasMore = true, count = 0, total: number | null = null;
  let cursor: string | null = null;
  try {
    while (hasMore && page <= 200) {
      const qs = new URLSearchParams({ page: String(page), pageSize: "1000", incluir_archivados: "true" });
      if (t.updated_since) qs.set("updated_since", new Date(t.updated_since).toISOString());
      const res = await fetch(`${t.base_url}?${qs}`, { headers: { Authorization: `Bearer ${t.api_token}` } });
      if (!res.ok) {
        let msg = `HTTP ${res.status}`;
        try {
          msg += `: ${(await res.json()).error}`;
        } catch { /* sin cuerpo */ }
        throw new Error(`La API de clientes respondió ${msg}`);
      }
      const body = await res.json();
      total = body.total ?? total;
      console.log(`[clients-sync] org ${t.organization_id} página ${page}: ${(body.data ?? []).length} de ${body.total ?? "?"} (updated_since=${t.updated_since ?? "todo"})`);
      const rows = (body.data ?? []).map(mapClient).filter((r: { external_id: string }) => r.external_id);
      for (const r of rows) if (r.updated_at && (!cursor || r.updated_at > cursor)) cursor = r.updated_at;
      // Lotes de 200 para no mandar cuerpos enormes a la base
      for (let i = 0; i < rows.length; i += 200) {
        const { data, error } = await admin.rpc("clients_upsert", { p_org: t.organization_id, p_code: t.default_code, p_rows: rows.slice(i, i + 200) });
        if (error) throw new Error(error.message);
        count += Number(data ?? 0);
      }
      hasMore = Boolean(body.hasMore);
      page++;
    }
    // En incrementales la API cuenta solo los que cambiaron: el total de Asesorías se guarda en las completas
    await admin.rpc("clients_sync_finish", { p_org: t.organization_id, p_ok: true, p_error: null, p_count: count, p_total: t.updated_since ? null : total, p_cursor: cursor });
    console.log(`[clients-sync] org ${t.organization_id} OK: ${count} guardados`);
    return { organization_id: t.organization_id, ok: true, count, total };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error(`[clients-sync] org ${t.organization_id} ERROR: ${msg}`);
    await admin.rpc("clients_sync_finish", { p_org: t.organization_id, p_ok: false, p_error: msg, p_count: count, p_total: total, p_cursor: null });
    return { organization_id: t.organization_id, ok: false, count, error: msg };
  }
}

serveWithCors(async (req) => {
  if (req.method !== "POST") return json({ error: "Método no permitido" }, 405);
  let body: { full?: boolean } = {};
  try {
    body = await req.json();
  } catch { /* cuerpo vacío */ }

  // Programada: todas las organizaciones con sincronización automática
  const secret = Deno.env.get("WEBHOOK_SECRET");
  if (secret && req.headers.get("x-webhook-secret") === secret) {
    const { data: targets, error } = await admin.rpc("clients_sync_targets", { p_org: null, p_full: Boolean(body.full) });
    if (error) return json({ error: error.message }, 500);
    const run = async () => {
      for (const t of targets ?? []) await syncOrg(t);
    };
    // deno-lint-ignore no-explicit-any
    const rt = (globalThis as any).EdgeRuntime;
    if (rt?.waitUntil) {
      rt.waitUntil(run());
      return json({ started: (targets ?? []).length, full: Boolean(body.full) }, 202);
    }
    await run();
    return json({ done: (targets ?? []).length });
  }

  // Desde la app: solo la organización del usuario, con permiso
  const auth = req.headers.get("Authorization") ?? "";
  const user = createClient(SUPABASE_URL, Deno.env.get("SUPABASE_ANON_KEY")!, {
    global: { headers: { Authorization: auth } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data: st, error: e1 } = await user.rpc("clients_source_status");
  if (e1) console.error(`[clients-sync] clients_source_status: ${e1.message}`);
  if (e1 || !st?.can_manage) return json({ error: "No tienes permiso para sincronizar clientes." }, 403);
  if (!st.connected) return json({ error: "Primero conecta la API de clientes." }, 400);
  const { data: me } = await user.auth.getUser(auth.replace("Bearer ", ""));
  const { data: prof } = await admin.from("profiles").select("organization_id").eq("id", me?.user?.id ?? "").single();
  const { data: targets, error } = await admin.rpc("clients_sync_targets", { p_org: prof?.organization_id, p_full: Boolean(body.full) });
  if (error) return json({ error: error.message }, 500);
  if (!targets?.length) return json({ error: "Ya hay una sincronización en curso. Intenta en unos minutos." }, 409);
  return json(await syncOrg(targets[0]));
});
